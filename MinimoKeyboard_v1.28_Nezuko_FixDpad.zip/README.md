# Minimo Keyboard v1.24

Cambios de esta versión:
- Mantener pulsada la tecla de último emoji abre directamente el teclado Emoji.
- Se intercambiaron las posiciones de la tecla emoji y la tecla de cambio de modo.
- Nuevo color **Rosa Waifu**.
- En Rosa Waifu, la barra espaciadora reemplaza el texto por una imagen anime/waifu.
- Se mantienen las funciones anteriores de frases en burbujas, gestos, RGB y personalización.


## Android TV / dispositivos no táctiles
- Compatible con dispositivos sin pantalla táctil (`android.hardware.touchscreen` es opcional).
- Incluye soporte para Android TV/Leanback como aplicación opcional.
- Las teclas son navegables mediante DPAD izquierda/derecha/arriba/abajo y se activan con DPAD_CENTER/Enter.
- Se mantienen los gestos táctiles en teléfonos y tablets.
- Mantener pulsadas las teclas `?`, emoji y `⏎` también tiene equivalente mediante el mando/DPAD.
