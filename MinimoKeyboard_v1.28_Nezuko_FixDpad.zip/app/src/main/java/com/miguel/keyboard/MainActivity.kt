package com.miguel.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Spinner
import android.widget.BaseAdapter
import android.widget.AbsListView
import android.view.ViewGroup
import android.graphics.Typeface
import android.widget.TextView
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("keyboard", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val vibrationSwitch = findViewById<Switch>(R.id.switchVibration)
        val vibrationSeek = findViewById<SeekBar>(R.id.seekVibration)
        val vibrationText = findViewById<TextView>(R.id.tvVibration)
        val soundSwitch = findViewById<Switch>(R.id.switchTypewriterSound)
        val rgbSwitch = findViewById<Switch>(R.id.switchRgbMode)
        val numberRowSwitch = findViewById<Switch>(R.id.switchNumberRow)
        val rgbWaveSpinner = findViewById<Spinner>(R.id.rgbWaveSpinner)
        val heightSeek = findViewById<SeekBar>(R.id.seekKeyboardHeight)
        val heightText = findViewById<TextView>(R.id.tvKeyboardHeight)
        val versionText = findViewById<TextView>(R.id.tvVersion)

        vibrationSwitch.isChecked = prefs.getBoolean("vibration_enabled", true)
        soundSwitch.isChecked = prefs.getBoolean("typewriter_sound_enabled", false)
        rgbSwitch.isChecked = prefs.getBoolean("rgb_mode_enabled", false)
        numberRowSwitch.isChecked = prefs.getBoolean("number_row_enabled", false)
        setupRgbWaveSelector(rgbWaveSpinner, rgbSwitch.isChecked)
        vibrationSeek.progress = prefs.getInt("vibration_strength", 45).coerceIn(0, 100)
        updateVibrationText(vibrationText, vibrationSeek.progress)

        val savedHeight = prefs.getInt("keyboard_height_percent", 100).coerceIn(70, 100)
        heightSeek.progress = savedHeight - 70
        updateHeightText(heightText, savedHeight)

        versionText.text = "Versión ${BuildConfig.VERSION_NAME}"
        setupColorSelector()
        setupLanguageSelector()
        setupPhrases()
        updateSectionTitleColors()
        applyRgbLabel(findViewById(R.id.switchRgbMode))

        findViewById<android.widget.Button>(R.id.btnEnable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        soundSwitch.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("typewriter_sound_enabled", enabled).apply()
            sendSettingsChanged()
        }

        rgbSwitch.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("rgb_mode_enabled", enabled).apply()
            rgbWaveSpinner.isEnabled = enabled
            sendSettingsChanged()
        }

        numberRowSwitch.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("number_row_enabled", enabled).apply()
            sendSettingsChanged()
        }

        vibrationSwitch.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("vibration_enabled", enabled).apply()
            sendSettingsChanged()
        }

        vibrationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val safe = progress.coerceIn(0, 100)
                prefs.edit().putInt("vibration_strength", safe).apply()
                updateVibrationText(vibrationText, safe)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) { vibrateConfiguredForOneSecond() }
        })

        heightSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val safe = (progress + 70).coerceIn(70, 100)
                prefs.edit().putInt("keyboard_height_percent", safe).apply()
                updateHeightText(heightText, safe)
                if (fromUser) sendSettingsChanged()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun setupRgbWaveSelector(spinner: Spinner, rgbEnabled: Boolean) {
        val options = listOf(
            "Expansiva",
            "Espiral",
            "Círculo",
            "Extremos → centro",
            "Rayos Zig Zag",
            "Ecualizador"
        )
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = options.size
            override fun getItem(position: Int): String = options[position]
            override fun getItemId(position: Int): Long = position.toLong()
            private fun row(position: Int): TextView = TextView(this@MainActivity).apply {
                text = options[position]
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.rgb(25, 25, 25))
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.rgb(65, 65, 65))
                }
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View = row(position)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View = row(position).apply {
                layoutParams = AbsListView.LayoutParams(-1, dp(48))
            }
        }
        spinner.adapter = adapter
        val saved = prefs.getString("rgb_wave_mode", "expanding") ?: "expanding"
        spinner.setSelection(when (saved) {
            "spiral", "sine" -> 1
            "circle", "cosine" -> 2
            "edges", "sine_cosine" -> 3
            "zigzag" -> 4
            "equalizer" -> 5
            else -> 0
        })
        spinner.isEnabled = rgbEnabled
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val key = when (position) {
                    1 -> "spiral"
                    2 -> "circle"
                    3 -> "edges"
                    4 -> "zigzag"
                    5 -> "equalizer"
                    else -> "expanding"
                }
                prefs.edit().putString("rgb_wave_mode", key).apply()
                if (rgbSwitchIsEnabled()) sendSettingsChanged()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
    }

    private fun rgbSwitchIsEnabled(): Boolean = prefs.getBoolean("rgb_mode_enabled", false)

    private data class ColorOption(val key: String, val name: String, val color: Int)

    private fun colorOptions(): List<ColorOption> = listOf(
        ColorOption("cloud", "Blanco Nube", Color.rgb(245, 245, 240)),
        ColorOption("yellow", "Amarillo Pastel", Color.rgb(255, 242, 166)),
        ColorOption("sky", "Azul Cielo", Color.rgb(135, 206, 235)),
        ColorOption("bubblegum", "Rosa Bubblegum", Color.rgb(255, 183, 213)),
        ColorOption("waifu", "Rosa Waifu", Color.rgb(255, 126, 185)),
        ColorOption("eva", "E.V.A.", Color.rgb(103, 56, 160)),
        ColorOption("nezuko", "Nezuko", Color.rgb(245, 145, 190)),
        ColorOption("olive", "Verde Oliva", Color.rgb(107, 125, 50)),
        ColorOption("gameboy", "Verde Gameboy", Color.rgb(138, 172, 15)),
        ColorOption("ferrari", "Rojo Ferrari", Color.rgb(255, 40, 0)),
        ColorOption("black", "Black AMOLED", Color.BLACK),
        ColorOption("transparent", "Transparente", Color.rgb(45, 45, 45))
    )

    private fun setupColorSelector() {
        val spinner = findViewById<Spinner>(R.id.colorSpinner)
        val options = colorOptions()
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = options.size
            override fun getItem(position: Int): ColorOption = options[position]
            override fun getItemId(position: Int): Long = position.toLong()

            private fun makeRow(position: Int, compact: Boolean): TextView = TextView(this@MainActivity).apply {
                val option = options[position]
                text = option.name
                textSize = if (compact) 15f else 16f
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setTextColor(if (isLightColor(option.color)) Color.rgb(25, 25, 25) else Color.WHITE)
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(if (compact) 10 else 12), dp(14), dp(if (compact) 10 else 12))
                background = GradientDrawable().apply {
                    setColor(option.color)
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), adjustOptionBorder(option.color))
                }
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return makeRow(position, true)
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return makeRow(position, false).apply {
                    val lp = AbsListView.LayoutParams(-1, dp(48))
                    layoutParams = lp
                }
            }
        }
        spinner.adapter = adapter
        val saved = prefs.getString("keyboard_color", "black") ?: "black"
        spinner.setSelection(options.indexOfFirst { it.key == saved }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val key = options[position].key
                if (key != (prefs.getString("keyboard_color", "black") ?: "black")) {
                    prefs.edit().putString("keyboard_color", key).apply()
                    updateSectionTitleColors()
                    sendSettingsChanged()
                }
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
    }

    private fun isLightColor(color: Int): Boolean {
        if (color == Color.TRANSPARENT) return false
        val luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color))
        return luminance > 160
    }

    private fun adjustOptionBorder(color: Int): Int {
        return if (isLightColor(color)) Color.argb(90, 0, 0, 0) else Color.argb(120, 255, 255, 255)
    }

    private fun setupLanguageSelector() {
        val container = findViewById<LinearLayout>(R.id.languageContainer)
        val languages = listOf(
            Triple("es", "🇪🇸", "Español"),
            Triple("pt", "🇧🇷", "Português"),
            Triple("en", "🇬🇧", "English")
        )
        container.removeAllViews()
        val saved = prefs.getString("keyboard_language", "es") ?: "es"
        languages.forEach { (key, flag, name) ->
            val button = TextView(this).apply {
                text = "$flag  $name"
                textSize = 15f
                gravity = android.view.Gravity.CENTER
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                isFocusable = true
                isClickable = true
                setPadding(dp(8), dp(12), dp(8), dp(12))
                layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                }
                setOnClickListener {
                    prefs.edit().putString("keyboard_language", key).apply()
                    updateLanguageButtons()
                    sendSettingsChanged()
                }
                tag = key
            }
            container.addView(button)
        }
        updateLanguageButtons()
    }

    private fun updateLanguageButtons() {
        val container = findViewById<LinearLayout>(R.id.languageContainer) ?: return
        val selected = prefs.getString("keyboard_language", "es") ?: "es"
        val accent = when (prefs.getString("keyboard_color", "black") ?: "black") {
            "eva" -> Color.rgb(150, 95, 220)
            "waifu" -> Color.rgb(255, 80, 160)
            else -> colorOptions().firstOrNull { it.key == prefs.getString("keyboard_color", "black") }?.color ?: Color.RED
        }
        for (i in 0 until container.childCount) {
            val view = container.getChildAt(i) as? TextView ?: continue
            val active = view.tag == selected
            view.setTextColor(if (active) Color.WHITE else Color.LTGRAY)
            view.background = GradientDrawable().apply {
                setColor(if (active) accent else Color.rgb(25, 25, 25))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(if (active) 2 else 1), if (active) accent else Color.rgb(65, 65, 65))
            }
        }
    }

    private fun setupPhrases() {
        val container = findViewById<LinearLayout>(R.id.phrasesContainer)
        val saved = loadPhrases()
        container.removeAllViews()
        saved.forEachIndexed { index, phrase ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val edit = EditText(this).apply {
                id = View.generateViewId()
                setText(phrase)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.DKGRAY)
                hint = "Frase ${index + 1}"
                textSize = 15f
                setSingleLine(true)
                setPadding(dp(10), 0, dp(10), 0)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(18, 18, 18))
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.rgb(55, 55, 55))
                }
                layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(0, dp(4), dp(8), dp(4))
                }
            }
            val save = ImageButton(this).apply {
                contentDescription = "Guardar frase ${index + 1}"
                setImageResource(R.drawable.ic_save)
                setColorFilter(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(35, 35, 35))
                    cornerRadius = dp(8).toFloat()
                }
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
                    setMargins(0, dp(4), 0, dp(4))
                }
                setOnClickListener {
                    prefs.edit().putString("phrase_${index + 1}", edit.text.toString()).apply()
                    sendSettingsChanged()
                    vibrateShort()
                    animate().scaleX(0.88f).scaleY(0.88f).setDuration(70L).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                    }.start()
                }
            }
            row.addView(edit)
            row.addView(save)
            container.addView(row)
            if (index == 0) {
                edit.requestFocus()
                edit.setSelection(0)
            }
        }
    }

    private fun applyRgbLabel(switch: Switch) {
        val label = SpannableStringBuilder("RGB Mode")
        label.setSpan(ForegroundColorSpan(Color.RED), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label.setSpan(ForegroundColorSpan(Color.GREEN), 1, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label.setSpan(ForegroundColorSpan(Color.BLUE), 2, 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        label.setSpan(ForegroundColorSpan(Color.WHITE), 3, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        switch.text = label
    }

    private fun loadPhrases(): List<String> {
        val defaults = listOf(
            "Voy a casa.",
            "Yendo.",
            "Te amo.",
            "Hola! Buenos dias!",
            "Ya lo hago.",
            "Donde queda eso?",
            "Si.",
            "No.",
            "Buenisimo.",
            "Ahora voy."
        )
        return defaults.mapIndexed { index, fallback ->
            prefs.getString("phrase_${index + 1}", fallback) ?: fallback
        }
    }

    private fun vibrateShort() {
        if (!prefs.getBoolean("vibration_enabled", true)) return
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val strength = prefs.getInt("vibration_strength", 45).coerceIn(0, 100)
            val amplitude = (1 + strength * 254 / 100).coerceIn(1, 255)
            vibrator.vibrate(VibrationEffect.createOneShot(18L, amplitude))
        } else {
            @Suppress("DEPRECATION") vibrator.vibrate(18L)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun updateSectionTitleColors() {
        val color = when (prefs.getString("keyboard_color", "black") ?: "black") {
            "bubblegum" -> Color.rgb(255, 105, 160)
            "waifu" -> Color.rgb(255, 80, 160)
            "olive" -> Color.rgb(170, 195, 80)
            "yellow" -> Color.rgb(210, 165, 0)
            "cloud" -> Color.rgb(120, 120, 120)
            "ferrari" -> Color.rgb(255, 105, 75)
            "transparent" -> Color.rgb(255, 70, 70)
            "sky" -> Color.rgb(70, 180, 230)
            "gameboy" -> Color.rgb(138, 172, 15)
            "eva" -> Color.rgb(150, 95, 220)
            "nezuko" -> Color.rgb(245, 145, 190)
            else -> Color.RED
        }
        listOf(
            R.id.tvTitle,
            R.id.tvActivation,
            R.id.tvVibrationTitle,
            R.id.tvHeightTitle,
            R.id.tvColorTitle,
            R.id.tvLanguageTitle,
            R.id.tvPhrasesTitle
        ).forEach { findViewById<TextView>(it)?.setTextColor(color) }
        updateLanguageButtons()
        updateVersionBubble()
    }

    private fun updateVersionBubble() {
        val version = findViewById<TextView>(R.id.tvVersion) ?: return
        val key = prefs.getString("keyboard_color", "black") ?: "black"
        val selected = colorOptions().firstOrNull { it.key == key }?.color ?: Color.BLACK
        val bubbleColor = if (key == "transparent") Color.rgb(45, 45, 45) else Color.argb(210, Color.red(selected), Color.green(selected), Color.blue(selected))
        val textColor = if (isLightColor(selected)) Color.rgb(20, 20, 20) else Color.WHITE
        version.setTextColor(textColor)
        version.setPadding(dp(10), dp(5), dp(10), dp(5))
        version.background = GradientDrawable().apply {
            setColor(bubbleColor)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), if (isLightColor(selected)) Color.argb(150,0,0,0) else Color.argb(170,255,255,255))
        }
    }

    private fun sendSettingsChanged() {
        sendBroadcast(Intent(MiguelKeyboardService.ACTION_SETTINGS_CHANGED).setPackage(packageName))
    }

    private fun updateVibrationText(view: TextView, value: Int) {
        view.text = "Intensidad: $value% · soltá el control para probar durante 1 segundo"
    }

    private fun updateHeightText(view: TextView, value: Int) { view.text = "Altura: $value%" }

    private fun vibrateConfiguredForOneSecond() {
        val strength = prefs.getInt("vibration_strength", 45).coerceIn(0, 100)
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val amplitude = (1 + strength * 254 / 100).coerceIn(1, 255)
            vibrator.vibrate(VibrationEffect.createOneShot(1000L, amplitude))
        } else {
            @Suppress("DEPRECATION") vibrator.vibrate(1000L)
        }
    }
}
